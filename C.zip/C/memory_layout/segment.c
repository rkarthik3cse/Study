text - contains executable instructions. This memory is shareable. It is a read-only memory.

data:
initialized - it has global and static variables initialized by programmer. 
              read-only  : constant literals are stored here. 
              read-write : normal variables are stored here.

uninitialized(bss) - uninitialized global, static variables are stored here.
                     global, static variables that are initialized to 0 is also stored here.

stack - automatic variables are stored here. A stack pointer tracks the top of the stack.
        Where to return after a function is completed is stored at bottom of a stack.
        Whenever a function is called, a fresh stack frame is created which stores the variables used in the function.
        For recursive functions, each call creates a unique stack frame.

heap - dynamically allotted memory is stored here. it is managed by malloc, realloc, calloc, free function.
