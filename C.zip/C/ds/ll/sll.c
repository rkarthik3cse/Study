#include <stdio.h>
#include <stdlib.h>

struct node
{
    int data;
    struct node *next;
};

typedef struct node Node;

void print_sll(Node *head)
{
    while(head != NULL)
    {
        printf("%d\t", head->data);
        head = head->next;
    }

    printf("\n");
}

void reverse(Node **head)
{
    Node *curr = *head;
    Node *dummy = NULL;
    Node *prev = NULL;

    while(curr!=NULL)
    {
        dummy = curr->next;
        curr->next = prev;
        prev = curr;
        curr = dummy;
    }
    
    *head = prev;
    
    return;
}

void delete_list(Node **head)
{
    Node *curr = *head;
    Node *next = NULL;

    while(curr!=NULL)
    {        
        next = curr->next;
        free(curr);
        curr = next;        
    }

    *head = NULL;
}

Node *create(int data)
{
    Node *tmp = (Node*) malloc(sizeof(Node));

    if(tmp==NULL)
    {
        printf("malloc failed!\n");
        exit(0);
    }

    tmp->data = data;
    tmp->next = NULL;

    return tmp;
}

void insert_at_middle(Node **head, int k, int data)
{
    Node *mid = *head;

    int i = 1;

    for(i=1;i<=(k-1);i++)
    {
        mid = mid->next;
    }
    
    Node *tmp = mid->next;

    Node *dummy = create(data);
    dummy->next = tmp;
    mid->next = dummy;
}

void insert_at_end(Node **head, int data)
{
    Node *tmp = create(data);

    if(*head == NULL)
    {
        *head = tmp;
        return;
    }

    Node *last = *head;

    while(last->next != NULL)
    {
        last = last->next;
    }

    last->next = tmp;
}

void insert_at_start(Node **head, int data)
{
    Node *tmp = create(data);

    if(*head == NULL)
    {
        *head = tmp;
        return;
    }   
    
    tmp->next = *head;
    *head = tmp;
}

int main()
{        
    Node *head = NULL;

    head = create(1);

    insert_at_end(&head, 2);
    insert_at_end(&head, 4);
    insert_at_end(&head, 5);

    insert_at_middle(&head, 2, 3);
    print_sll(head);
    reverse(&head);
    print_sll(head);
    delete_list(&head);
    print_sll(head);

    return 0;
}
