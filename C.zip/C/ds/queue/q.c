#include <stdio.h>
#include <stdlib.h>

struct node
{
    int data;
    struct node *next;
};

typedef struct node Node;

void print_q(Node *head)
{
    while(head != NULL)
    {
        printf("%d\t", head->data);
        head = head->next;
    }

    printf("\n");
}

Node *create(int data)
{
    Node *tmp = (Node*) malloc(sizeof(Node));

    if(tmp==NULL)
    {
        printf("malloc failed!\n");
        exit(0);
    }

    tmp->data = data;
    tmp->next = NULL;

    return tmp;
}

void dequeue(Node **head)
{
    Node *curr = *head;
    Node *prev = NULL;
    
    while((curr->next) != NULL)
    {
        prev = curr;
        curr = curr->next;
    }

    prev->next = NULL;
    free(curr);
}

void enqueue(Node **head, int data)
{
    Node *tmp = create(data);

    if(*head == NULL)
    {
        *head = tmp;
        return;
    }

    Node *last = *head;

    while(last->next != NULL)
    {
        last = last->next;
    }

    last->next = tmp;
}

int main()
{        
    Node *head = NULL;

    head = create(1);

    enqueue(&head, 2);
    enqueue(&head, 3);
    enqueue(&head, 4);
    print_q(head);
    dequeue(&head);

    print_q(head);

    return 0;
}
