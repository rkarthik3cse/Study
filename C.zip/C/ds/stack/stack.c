#include <stdio.h>
#include <stdlib.h>

struct node
{
    int data;
    struct node *next;
};

typedef struct node Node;

void print_stack(Node *head)
{
    while(head != NULL)
    {
        printf("%d\t", head->data);
        head = head->next;
    }

    printf("\n");
}

int is_empty(Node *head)
{
    if(head==NULL)
    {
        printf("Stack is Empty\n");
        return 1;
    }

    return 0;
}

int top(Node *head)
{
    if(!is_empty(head))
    {
        return head->data;
    }
}

Node *create(int data)
{
    Node *tmp = (Node*) malloc(sizeof(Node));

    if(tmp==NULL)
    {
        printf("malloc failed!\n");
        exit(0);
    }

    tmp->data = data;
    tmp->next = NULL;

    return tmp;
}

void push(Node **head, int data)
{
    Node *tmp = create(data);

    if(*head == NULL)
    {
        *head = tmp;
        return;
    }   
    
    tmp->next = *head;
    *head = tmp;
}

void pop(Node **head)
{
    Node *curr = *head;
    Node *next = NULL;

    if(!is_empty(curr))
    {
        next = curr->next;
        free(curr);
        *head = next;
    }
}

int main()
{        
    Node *head = NULL;

    int tmp = 0;

    head = create(1);

    push(&head, 2);
    push(&head, 3);
    push(&head, 4);
    push(&head, 5);

    print_stack(head);
    pop(&head);
    print_stack(head);

    return 0;
}
