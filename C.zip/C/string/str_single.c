#include <stdio.h>
#include <string.h>

int main()
{
    char a[6] = {'H', 'e', '\0', 'l', 'l', 'o'};

    printf("%s\n", a);              // "He" (In C, a string is terminated using '\0')
    printf("%lu\n", strlen(a));     //  2
    printf("%lu\n", sizeof(a));     //  6

    return 0;
}

