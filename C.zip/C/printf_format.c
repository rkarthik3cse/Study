#include <stdio.h>

int main()
{
    int a = 5;
    printf("%d\n", a);
    printf("%.5d\n", a);       // Add leading zeroes
    printf("%5d\n", a);        // Add whitespaces

    return 0;
}

