//Runtime: O(1)

#include<stdio.h>

int main()
{
    int num = -16, k = 1, i = 0, tmp = 0;

    for(i=0;i<31;i++)
    {
        tmp = k << i;
        printf("i: %d\t%10d\t", i, k << i);
        (tmp&num) ? printf("Bin: %d\n", 1) : printf("Bin: %d\n", 0);
   }

    return 0;
}

