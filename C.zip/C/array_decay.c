// C Program to Demonstrate the Array Decay
#include <stdio.h>
 
// function
void func(int* arr)
{
    printf("Sizeof Value in Function: %d", sizeof(arr));  // Value is 8 (arr is a Pointer, Size of Pointer is 8).
}
 
int main()
{
 
    // creating array with 3 elements
    char arr[3];
 
    printf("Sizeof Value in Main: %d\n", sizeof(arr)); // Value is 3. "arr" is array name
 
    // passing array
    func(arr);
 
    return 0;
}
