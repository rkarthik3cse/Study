struct Student
{
    char name[50];
    int rank;
};

struct Student s1;

***************************************************************************************************************************************************************************

While creating structure object, we need to use struct keyword everytime. This consumes more characters in a line.
To avoid this, we can use typedef.

typedef struct
{
    char name[50];
    int rank;
} Student;


Student s1;
***************************************************************************************************************************************************************************

