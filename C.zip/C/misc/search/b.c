#include <stdio.h>

int b_search(int num, int low, int high, int a[])
{
    if(low<=high)
    {
        int mid = (low + high) / 2;    

        if(num==a[mid])
        {
            return 1;
        }
        else
        if(num>a[mid])
        {
            low = mid+1;
            return b_search(num,low,high,a);
        }
        else
        {
            high = mid-1;
            return b_search(num,low,high,a);
        }
    }

    return 0;
}

int main()
{
    int result = 0;
    int a[10] = {1,2,3,4,5,6,7,8,9,10};

    result = b_search(7, 0, 9, a);
    printf("7:%d\n", result);

    result = b_search(88, 0, 9, a);
    printf("88:%d\n", result);

    return 0;
}
