#include <stdio.h>

int main()
{
    int a[7] = {11,22,33,44,55,66,77};
    int sum = 99;
    int i = 0, j = 6, result = 0, tmp = 0;

    for(;;)
    {
        if(i==j)
        {
            break;
        }
        tmp = a[i] + a[j];
        if(tmp == sum)
        {
            result = 1;            
            break;
        }
        else
        if(tmp > sum)
        {
            j--;
        }
        else
        {
            i++;
        }
    }
    
    if(result)
    {
        printf("i:%d\t, j:%d\n", i, j);
    }
    else
    {
        printf("Sum is not present\n");
    }    

    return 0;
}
