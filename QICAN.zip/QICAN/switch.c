#include <stdio.h>

int main()
{
    int l = 10;

    switch(l)
    {
        case 5 ... 9:
            printf("5 to 9\n");
            break;
        case 10 ... 15:
            printf("10 to 15\n");
            break;
        default:
            printf("default\n");
    }
}
