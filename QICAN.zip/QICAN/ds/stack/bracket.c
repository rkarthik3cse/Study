#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct node
{
    int data;
    struct node *next;
};

typedef struct node Node;

void print_stack(Node *head)
{
    while(head != NULL)
    {
        printf("%c\t", head->data);
        head = head->next;
    }

    printf("\n");
}

int is_br_open(char a)
{
    if((a =='{') || (a == '(') || (a == '[') || (a == '<'))
    {
        return 1;
    }

    return 0;
}

int is_empty(Node *head)
{
    if(head==NULL)
    {
        printf("Stack is Empty\n");
        return 1;
    }

    return 0;
}

char top(Node *head)
{
    if(!is_empty(head))
    {
        return head->data;
    }
}

Node *create(int data)
{
    Node *tmp = (Node*) malloc(sizeof(Node));

    if(tmp==NULL)
    {
        printf("malloc failed!\n");
        exit(0);
    }

    tmp->data = data;
    tmp->next = NULL;

    return tmp;
}

void push(Node **head, int data)
{
    Node *tmp = create(data);

    if(*head == NULL)
    {
        *head = tmp;
        return;
    }   
    
    tmp->next = *head;
    *head = tmp;
}

void pop(Node **head)
{
    Node *curr = *head;
    Node *next = NULL;

    if(!is_empty(curr))
    {
        next = curr->next;
        free(curr);
        *head = next;
    }
}

void balance(char a, char b, Node **head)
{
    if(((a=='(') && (b ==')')) || ((a=='{') && (b =='}')) ||
       ((a=='[') && (b==']')) || ((a=='<') && (b=='>')))
    {
        pop(head);
    }
}

int main()
{        
    Node *head = NULL;

    char str[10]="{([<]>)}";

    char tmp;

    int i, len = 0;
    len = strlen(str);

    printf("Len:%d\n", len);

    for(i=0;i<len;i++)
    {
        if(is_br_open(str[i]))
        {
            push(&head, str[i]);
        }
        else
        {
            balance(top(head), str[i], &head);
        }
    }

    if(is_empty(head))
    {
        printf("Balanced\n");
    }
    else
    {
        printf("Not balanced\n");
    }
    
    return 0;
}
