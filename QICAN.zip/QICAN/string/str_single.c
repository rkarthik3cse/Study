#include <stdio.h>
#include <string.h>

int main()
{
    char a[6] = {'H', 'e', '\0', 'l', 'l', 'o'};
    char b[6], c[6];
    
    
    printf("%s\n", a);              // "He" (In C, a string is terminated using '\0')
    printf("%lu\n", strlen(a));     //  2
    printf("%lu\n", sizeof(a));     //  6
    strcpy(b,a);
    memcpy(c,a,6);
    printf("b: %s\n", b);
    printf("c: %s\n", c);
    return 0;
}

