#include <stdio.h>
#include <string.h>

int main()
{
    int l1, l2, l3 = 0;
    int s1, s2, s3, s4 = 0;
    
    char a[] = "Hello";
    char b[6] = "Hello";
    char *c = "Hello";
    
    
    l1 = strlen(a);
    l2 = strlen(b);
    l3 = strlen(c);
    
    s1 = sizeof(a);
    s2 = sizeof(b);
    s3 = sizeof(c);
    s4 = sizeof(*c);
    
    printf("Len\tSize\n");
    
    printf("%d\t%d\n", l1, s1); // 5, 6  ('\0' is automatically appended for character array initialised using double quotes)
    printf("%d\t%d\n", l2, s2); // 5, 6  ('\0' is automatically appended for character array initialised using double quotes)
    printf("%d\t%d\n", l3, s3); // 5, 8  (Size of any Pointer is 8)
    printf("\t%d\n", s4);       //    1  (*c is a character. Size of character is 1)
}

