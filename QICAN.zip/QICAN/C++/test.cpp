#include <iostream>

using namespace::std;

class test
{
    int a;
    int *b;

    public:
        test()
        {
            a = 5;
            b = new int;
            *b = 7;
        }
        void print()
        {
            cout<<a<<"\t"<<&a<<endl;
            cout<<*b<<"\t"<<b<<endl;
        }

        ~test()
        {
            delete b;
        }
};

int main()
{
    test t;
    t.print();
    test t1(t);
    t1.print();
}
