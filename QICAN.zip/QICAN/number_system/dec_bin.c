//Runtime: O(log2 n)

#include<stdio.h>

int main()
{
    int dec = 128, i = 0, qt = 0, rem = 0;
    int bin[32] = {0};

    qt = dec;

    while(qt > 0)
    {
        rem = qt%2;
        qt  = qt/2;
        bin[i] = rem;
        i++;
        printf("%d\t", rem);
    }

    printf("\n");

    for(i=31;i>=0;i--)
    {
        printf("%d", bin[i]);
    }

    printf("\n");
    return 0;
}

