#include <stdio.h>

int square_sum(int n)
{
    int tmp = 0, sum = 0;
    
    while(n>0)
    {
        tmp = n%10;
        n = n/10;
        sum += tmp*tmp;
    }
    
    return sum;
}


int is_happy_number(int n)
{
    int slow , fast = 0;
    slow = fast = n;

    do
    {
        slow = square_sum(slow);
        fast = square_sum(square_sum(fast));
        printf("slow:%d\tfast:%d\n", slow, fast);
    } while(slow != fast);

    if(slow == 1)
        return 1;
    else
        return 0;
}

int main()
{
    is_happy_number(19) ? printf("Yes\n") : printf("No\n");

    return 0;
}
