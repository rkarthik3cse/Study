#include <stdio.h>

int remove_duplicate(int a[], int size)
{
    int i = 0, j = 1, k = 0;

    for(i=0;i<size;i++)
    {
        if(a[j] > a[i])
            continue;

        for(k=j;k<size;k++)
        {
            if(a[k] > a[i])
            {
                a[i+1] = a[k];
                j = k+1;
                break;
            }
        }        
    }

    return 0;
}

int get_unique_count(int a[], int size)
{
    int i = 0, count = 0;

    for(i=0;i<size-1;i++)
    {
        if(a[i+1]>a[i])
            count++;
        else
            break;
    }

    return count+1;
}

int print(int a[], int size)
{
    int i = 0;
    for(i=0;i<size;i++)
    {
        printf("%d\t", a[i]);
    }
    printf("\n");
}

int main()
{
    int a[4] = {1,2,3,4};
    int size = sizeof(a)/sizeof(a[0]);
    int result = 0;

    print(a, size);
    remove_duplicate(a, size);
    print(a, size);

    result = get_unique_count(a, size);

    printf("No. of Unique elements: %d\n", result);

    return 0;
}
