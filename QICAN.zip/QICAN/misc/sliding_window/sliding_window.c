#include <stdio.h>

int test(int a[])
{
    int i=0, k = 2;
    int curr_sum = 0, result = 0;

    for(i=0;i<k;i++)
    {
        curr_sum+= a[i];
    }
    result = curr_sum;
    
    for(i=k;i<7;i++)
    {
        curr_sum = curr_sum + a[i] - a[i-k];
        if(result<curr_sum)
        {
            result = curr_sum;
        }
    }
    printf("Result: %d\n", result);
}


int main()
{
    int a[7] = {2,3,4,100,6,5,22};
    test(a);
}
