#include <stdio.h>

int main()
{
    int n = 5;
    int i = 0;

    int f[5] = {0};

    f[0] = 0;
    f[1] = 1;    

    for(i=2;i<n;i++)
    {
        f[i] = f[i-2] + f[i-1];
    }

    for(i=0;i<n;i++)
    {
        printf("%d\n", f[i]);
    }

    printf("\n");

    return 0;
}
