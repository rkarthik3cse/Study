#include <stdio.h>

int main()
{
    int i = 0, n = 5, result = 1;

    while(n>0)
    {
        result = result * n;
        n--;
    }
    printf("Result: %d\n", result);

    return 0;    
}

