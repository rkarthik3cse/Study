#include <stdio.h>

int fact(int n)
{
    if(n==1)
    {
        return 1;
    }
    else
    {
        return (n * fact(n-1));
    }
}

int main()
{
    int i = 0, n = 5, result = 1;
    result = fact(n);

    printf("%d\n", result);

    return 0;    
}

