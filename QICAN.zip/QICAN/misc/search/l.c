#include <stdio.h>

int search(int n, int a[10])
{
    int i = 0;
    for(i=0;i<10;i++)
    {
        if(n==a[i])
        {
            return 1;
        }
    }
    return 0;
}

int main()
{
    int result = 0;
    int a[10] = {1,6,2,4,8,9,10,5,3,7};
    result = search(7, a);
    printf("7:%d\n", result);
    result = search(88, a);
    printf("88:%d\n", result);

    return 0;
}
